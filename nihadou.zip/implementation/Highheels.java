import java.util.Scanner;
public class Highheels extends Shoes{
	private double inch;
	private double mark;

public Highheels(String name, String size, String quantity, String price){
super(name, size, quantity, price);
	this.inch= inch;
	this.mark= mark;
}

public static void main(String args[]){
	System.out.println("enter name of shoes");
	name= niha.next();
	System.out.println("enter size of shoes");
	size= niha.next();
	System.out.println("enter quantity of shoes");
	quantity= niha.next();
	System.out.println("enter price of shoes");
	price= niha.next();
	System.out.println("enter inch of shoes");
	inch= niha.nextDouble();
	System.out.println("enter mark of shoes");
	mark= niha.nextDouble();
}

	switch(quantity){
	case 1:
	System.out.println("Tzs 20.000");
	case 2:
	System.out.println("Tzs 30.000");
	case 3:
	System.out.println("Tzs 40.000");
	case 4:
	System.out.println("Tzs 50.000");
	case 5:
	System.out.println("Tzs 60.000");

	}


default{
System.out.println("You can not make more order");
System.out.println("Your supplier name is khalida");
System.out.println("Address New York");
System.out.println("Contact +212678909677");
System.out.println("email khalida@gmail.com");

}


}