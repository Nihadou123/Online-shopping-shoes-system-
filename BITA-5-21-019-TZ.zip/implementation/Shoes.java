public class Shoes{
	private String name;
	private String size;
	private String quantity;
	private String price;

	public String Shoes(String name, String size, String quantity, String price){
		This.name= name;
		This.size= size;
		This.quantity= quantity;
		This.price= price;
	}

	public String getname(){
		return name;
	}

	public String getsize(){
		return size;
	}

	public String getquantity(){
		return quantity;
	}

	public String getprice(){
		return price;
	}

	public static void main(String[] niha){
		Shoeses Sh= new Shoeses(System.in);
		name= Sh.nextLine("BOOT");
		size= Sh.nextLine("34");
		quantity= Sh.nextLine("67");
		price= Sh.nextLine("frc 40000");
	}

}