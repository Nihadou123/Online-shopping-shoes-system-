import java.util.Scanner;
public class Highheels extends Shoes{
public static void main(String[] niha){
	private double inch;

public Highheels(String name, String size, String quantity, String price){
	This.inch= inch;
}

Scanner niha= new Scanner(System.in);
	System.out.println("enter name of shoes");
	name= niha.nextLine();
	System.out.println("enter size of shoes");
	size= niha.nextLine();
	System.out.println("enter quantity of shoes");
	quantity= niha.nextLine();
	System.out.println("enter price of shoes");
	price= niha.nextLine();
	System.out.println("enter inch of shoes");
	inch= niha.nextLine();


	Switch(quantity){
	quantity 1:
	System.out.println("Tzs 20.000");
	quantity 2:
	System.out.println("Tzs 30.000");
	quantity 3:
	System.out.println("Tzs 40.000");
	quantity 4:
	System.out.println("Tzs 50.000");
	quantity 5:
	System.out.println("Tzs 60.000");	
}

default{
System.out.println("You can not make more order"){

}

System.out.println("Your supplier name is khalida");
System.out.println("Address New York");
System.out.println("Contact +212678909677");
System.out.println("email khalida@gmail.com");

}

}